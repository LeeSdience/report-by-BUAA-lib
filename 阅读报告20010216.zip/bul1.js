/*
 Highcharts JS v7.2.0 (2019-09-03)

 (c) 2009-2019 Torstein Honsi

 License: SDIENCELEE FROM www.highcharts.com/license
*/
(function(a) {
  "object" === typeof module && module.exports ? (a["default"] = a, module.exports = a) : "function" === typeof define && define.amd ? define("highcharts/themes/skies", ["highcharts"],
  function(b) {
    a(b);
    a.Highcharts = b;
    return a
  }) : a("undefined" !== typeof Highcharts ? Highcharts: void 0)
})(function(a) {
  function b(a, b, c, d) {
    a.hasOwnProperty(b) || (a[b] = d.apply(null, c))
  }
  a = a ? a._modules: {};
  b(a, "themes/skies.js", [a["parts/Globals.js"]],
  function(a) {
    a.theme = {
      colors: "#02569C #E27933 #A5A5A5 #F4BA1B #416CB4 #6EA647".split(" "),
      chart: {
        className: "skies",
        plotBackgroundColor: {
          linearGradient: [0, 0, 250, 500],
          stops: [[0, "rgba(255, 255, 255, 1)"], [1, "rgba(255, 255, 255, 0)"]]
        }
      },
      title: {
        style: {
          color: '#02569C',
          font: 'bold 24px "黑体"'
        }
      },
      subtitle: {
        style: {
          color: '#02569C',
          font: 'italic "黑体"'
        }
      },
      lang: {
        viewData: '查看数据表格',
        openInCloud: '在线编辑',
        decimalPoint: '.',
        thousandsSep: ','
      },
      xAxis: {
        gridLineWidth: 0,
        lineColor: "#C0D0E0",
        tickColor: "#C0D0E0",
        labels: {
        style: {
          color: "#000000",
          font: 'italic "宋体"'
        }
        },
        title: {
        style: {
          color: "#02569C",
          font: 'italic "宋体"'
        }
        }
      },
      yAxis: {
        alternateGridColor: "rgba(255, 255, 255, .5)",
        lineColor: "#C0D0E0",
        tickColor: "#C0D0E0",
        tickWidth: 1,
        labels: {
        style: {
          color: "#000000",
          font: 'italic "宋体"'
        }
        },
        title: {
        style: {
          color: "#000000",
          font: 'italic "宋体"'
        }
        }
      },
      legend: {
        itemStyle: {
          font: "9pt Trebuchet MS, Verdana, sans-serif",
          color: "#3E576F"
        },
        itemHoverStyle: {
          color: "black"
        },
        itemHiddenStyle: {
          color: "silver"
        }
      },
      credits: {
        style: {
          color: "#000000",
          font: 'italic "宋体"'
        },
        text: '北航图书馆',
        href: 'http://lib.buaa.edu.cn/'
      },
      labels: {
        style: {
          color: "#000000",
          font: 'italic "宋体"'
        }
      }
    };
    a.setOptions(a.theme)
  });
});
//# sourceMappingURL=skies.js.map
